clientes_registrados = {"604890472": "Sebastian", "703110804": "Axel"}

# Función para registrar un cliente
def registrar_cliente(cedula, nombre, telefono):
    if cedula not in clientes_registrados:
        clientes_registrados[cedula] = nombre
        print("Cliente {} registrado con exito.".format(nombre))
    else:
        print("El cliente ya esta registrado.")

print("\nInicio de sesion:")
cedula = input("Ingrese su numero de cedula: ")
cliente = clientes_registrados.get(cedula)

# Si el cliente no está registrado, solicitar detalles y registrar.
if cliente is None:
    nombre = input("Ingrese su Nombre: ")
    telefono = input("Ingrese su Numero de Telefono: ")
    registrar_cliente(cedula, nombre, telefono)
else:
    print("Bienvenido,", cliente)
#Definir las variables del programa.
cliente = input(str("Ingrese su Nombre: "))
Toyota = str("Toyota")
hyundai = str("Hyundai")
Honda = str("Honda")
Nissan = str("Nissan")
Suzuki = str("Suzuki")
print("Hola", cliente , "espero que tengas una muy buena atencion el siguiente paso es elegir el modelo del vehiculo que quieras reservar.")
name = str(input("Ingrese el marca del auto que desea reservar: "))
if name == Toyota:
    print("Toyota corolla: Quedan 4 disponibles.")
    print("Toyota Rav4: No disponibles por el momento.")
    print("Toyota Hilux: Quedan 3 disponibles.")
    print("Toyota Yaris: Quedan 2 disponibles.")
elif name == hyundai:
    print("Hyundai Accent: No hay disponibles por el momento.")
    print("Hyundai Santa Fe: Quedan 2 disponibles.")
    print("Hyundai Elantra: Queda 1 disponible. ")
elif name == Honda:
     print("Honda Civic: Queda 3 disponible. ")
     print("Honda CR-V: Queda 2 disponible. ")
     print("Honda Accord: No hay disponible por el momento. ")
elif name == Nissan:
     print("Nissan Qashqai: Queda 3 disponible. ")
     print("Nissan Pathfinder: Queda 2 disponible. ")
     print("Nissan Sentra: No hay disponible por el momento. ")
elif name == Suzuki:
     print("Suzuki Vitara: Queda 2 disponible. ")
     print("Suzuki Swift: Queda 1 disponible. ")
     print("Suzuki Celerio : No hay disponible por el momento. ")
else:
    print("Disculpe, Desea elegir otro vehiculo")
print("Ya sabes cuantos autos hay disponibles, ahora el siguiente paso es elejir el modelo del auto. ")

#Elejir  el modelo del auto 
Corolla = str("Corolla")
Rav4 = str("Rav4")
Hilux = str("Hilux")
Yaris = str("Yaris")
#Aca termina los modelos de Toyota y empiezan los de Hyundai.
Accent = str("Accent")
SantaFe = str("SantaFe")
Elantra = str("Elantra")
#Aca termina los modelos de Hyundai y empiezan los de Honda.
Civic = str("Civic")
CR_V = str("CR-V")
Accord = str("Accord")
#Aca termina los modelos de Honda y empiezan los de Nissan.
Qashqai = str("Qashqai")
Pathfinder = str("Pathfinder")
Sentra = str("Sentra")
#Aca termina los modelos de Nissan y empiezan los de Suzuki.
Vitara = str("Vitara")
Swift = str("Swift")
Celerio = str("Calerio")
modelo = str(input("Que modelo de auto desea reservar: " ))
print("Elejiste el modelo", name, modelo)
if modelo == Corolla:
    print("Marca: Toyota | Año: 2017 | Cilindraje: 4 cilindros | Precio del vehículo: 7.000.000  | placa: MTZ-098 | Color: Gris ")
    print("Marca: Toyota | Año: 2020 | Cilindraje: 4 cilindros | Precio del vehículo: 11.000.000 | placa: QWR-908 | Color: Negro ")
    print("Marca: Toyota | Año: 2022 | Cilindraje: 4 cilindros | Precio del vehículo: 14.000.000 | placa: NPL-809 | Color: Blanco ")
    print("Marca: Toyota | Año: 2019 | Cilindraje: 4 cilindros | Precio del vehículo: 10.000.000 | placa: ZJK-980 | Color: Azul Marino")
elif modelo == Rav4:
    print("No disponible por el momento, ¿desea cambiar de Sede?")
elif modelo == Hilux:
     print("Marca: Toyota | Año: 2019 | Cilindraje: 4 cilindros | Precio del vehículo: 9.000.000  | placa: XZL-256 | Color: Rojo")
     print("Marca: Toyota | Año: 2019 | Cilindraje: 4 cilindros | Precio del vehículo: 13.000.000 | placa: HJG-625 | Color: blanco ")
     print("Marca: Toyota | Año: 2019 | Cilindraje: 4 cilindros | Precio del vehículo: 16.000.000 | placa: OQW-526 | Color: Negro ")
elif modelo == Yaris:
     print("Marca: Toyota | Año: 2019 | Cilindraje: 3 cilindros | Precio del vehículo: 7.000.000 | placa: KLV-801 | Color: Rojo ")
     print("Marca: Toyota | Año: 2019 | Cilindraje: 3 cilindros | Precio del vehículo: 5.000.000 | placa: VLK-108 | Color: Celeste") 
#Terminan los modelos de Toyota.
elif modelo == Accent:
     print("No disponible por el momento, ¿desea cambiar de Sede?")
elif modelo == SantaFe:
     print("Marca: Hyundai | Año: 2022 | Cilindraje: 4 cilindros | Precio del vehículo: 12.000.000 | placa: NBC-364  | Color: Rojo") 
     print("Marca: Hyundai | Año: 2019 | Cilindraje: 4 cilindros | Precio del vehículo: 9.000.000  |  placa: BCN-463 | Color: Gris ")
elif modelo == Elantra: 
      print("Marca: Hyundai | Año: 2018 | Cilindraje: 4 cilindros | Precio del vehículo: 10.000.000| placa: QML-048 | Color: Negro")
#Termina los modelos de Hyundai.
elif modelo == Civic:
      print("Marca: Honda | Año: 2018 | Cilindraje: 4 cilindros | Precio del vehículo: 13.000.000 | placa: RJV-718 | Color: Rojo")
      print("Marca: Honda | Año: 2017 | Cilindraje: 4 cilindros | Precio del vehículo: 10.000.000 | placa: JVR-871 | Color: Verde Oscuro")
      print("Marca: Honda | Año: 2020 | Cilindraje: 4 cilindros | Precio del vehículo: 15.000.000 | placa: VRJ-178 | Color: Negro")
elif modelo == CR_V:
     print("Marca: Honda | Año: 2022 | Cilindraje: 4 cilindros | Precio del vehículo: 13.000.000 | placa: KJD-257  | Color: Gris")
     print("Marca: Honda | Año: 2018 | Cilindraje: 4 cilindros | Precio del vehículo: 11.000.000 | placa: DJK-752  | Color: Negro")
elif modelo == Accord:
     print("No disponible por el momento, ¿desea cambiar de Sede?")
#Terminan los modelos de Honda.
elif modelo == Qashqai:
     print("Marca: Nissan | Año: 2017 | Cilindraje: 4 cilindros | Precio del vehículo: 11.000.000 | placa: SWQ-912  | Color: Gris")
     print("Marca: Nisaan | Año: 2018 | Cilindraje: 4 cilindros | Precio del vehículo: 14.000.000 | placa: WQS-291  | Color: Blanco")
     print("Marca: Nissan | Año: 2021 | Cilindraje: 4 cilindros | Precio del vehículo: 17.000.000 | placa: QSW-192  | Color: Azul")
elif modelo == Pathfinder:
     print("Marca: Nissan | Año: 2017 | Cilindraje: 6 cilindros | Precio del vehículo: 13.000.000 | placa: ZXL-602  | Color: Blanco")
     print("Marca: Nissan | Año: 2020 | Cilindraje: 6 cilindros | Precio del vehículo: 16.000.000 | placa: LZX-206  | Color: Azul Oscuro")
elif modelo == Sentra:
     print("No disponible por el momento, ¿desea cambiar de Sede?")
#Termina los modelos de Nissan.
elif modelo == Vitara:
     print("Marca: Suzuki | Año: 2017 | Cilindraje: 4 cilindros | Precio del vehículo: 9.000.000  | placa: FGH-320  | Color: Blanco")
     print("Marca: Suzuki | Año: 2020 | Cilindraje: 4 cilindros | Precio del vehículo: 12.000.000 | placa: HFG-032  | Color: Blanco")
elif modelo == Swift:
     print("Marca: Suzuki | Año: 2020 | Cilindraje: 4 cilindros | Precio del vehículo: 10.000.000 | placa: XMN-387  | Color: Blanco")
elif modelo == Celerio:
      print("No disponible por el momento, ¿desea cambiar de Sede?")
else:
    print("Disculpe, Desea elegir otro vehiculo")
    
print("print indefinido")
año = int(input("Cual seria el año del automovil que quieres: "))
