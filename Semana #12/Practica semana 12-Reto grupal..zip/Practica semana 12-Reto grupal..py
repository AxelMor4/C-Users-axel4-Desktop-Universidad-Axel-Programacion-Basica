import os

archivo_practica = "practica_progra.txt"

while True:
    print("Bienvenido al registro de montos en dolares del grupo 3")
    accion = int(input("Por favor digite 1 para ingresar un monto, 2 para ver todos los montos o 3 para salir: "))
    
    if accion == 1:
        montos = input("Digite su nombre y el monto en dólares que desea ingresar: ")
        with open(archivo_practica, "a") as archivo:
            archivo.write(montos + "\n")
    elif accion == 2:
        with open(archivo_practica, "r") as archivo:
            print("Montos en dolares ingresados:")
            for linea in archivo:
                print(linea.strip())
    elif accion == 3:
        print("Gracias por utilizar este programa")
        break
    else:
        print("Opción no válida. Por favor, seleccione 1, 2 o 3.")
