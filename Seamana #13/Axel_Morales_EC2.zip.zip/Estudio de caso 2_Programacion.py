import os

# Lista de doctores autorizados
doctores_autorizados = [
    "Juan Romero",
    "Sofia Tames"
]

# Solicitar el nombre del usuario
medico = input("Ingrese el nombre del usuario (únicamente de los médicos jefes): ")

# Verificar si el nombre del usuario está en la lista de doctores autorizados
if medico in doctores_autorizados:
    print("Entraste con éxito al sistema de citas.")
    
    # Solicitar la acción que el usuario desea realizar
    while True:
        try:
            accion = int(input("Ingrese 1 para apartar una cita, 2 para ver todas las citas o 3 para salir del sistema de citas: "))
            
            if accion == 1:
                # Apartar una cita
                cita = input("Digite el nombre de la persona de la cita y la fecha en la que quiere apartar la cita: ")
                # Nombre del archivo donde se guardarán las citas (debes especificar la ruta si no está en el mismo directorio)
                archivo_practica = "citas.txt"
                with open(archivo_practica, "a") as archivo:
                    archivo.write(cita + "\n")
                print("Cita apartada con éxito.")
            elif accion == 2:
                # Ver todas las citas
                # Nombre del archivo donde están almacenadas las citas
                archivo_practica = "citas.txt"
                with open(archivo_practica, "r") as archivo:
                    citas = archivo.readlines()
                print("Todas las citas:")
                for cita in citas:
                    print(cita.strip())
            elif accion == 3:
                # Salir del sistema
                print("Saliendo del sistema de citas.")
                break
            else:
                print("Opción inválida. Por favor, ingrese un número entre 1 y 3.")
        except ValueError:
            print("Entrada inválida. Por favor, ingrese un número.")
else:
    print("Usted no forma parte de los médicos jefes, únicamente solo médicos jefes pueden ingresar al sistema.")
